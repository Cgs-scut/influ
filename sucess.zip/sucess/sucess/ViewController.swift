//
//  ViewController.swift
//  sucess
//
//  Created by Apple on 2019/9/24.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var hiddenlabel: UILabel!
    @IBOutlet weak var password: UITextField!
    
    @IBAction func Login(_ sender: Any) {
        if(name.text == "xin" )&&(password.text == "123"){
            hiddenlabel.isHidden = false
            hiddenlabel.text = "sucessfully Login"
            
        }
        else{
            hiddenlabel.isHidden = false
            hiddenlabel.text = "input wrong information"
            
        }
        
        
    }
    
}

