import UIKit

var pokes = [Int]();
for i in 0...51{
    pokes.append(i)
    
}


func pokes_type(poke:Int) -> String {
    let count = poke/4+1
    let huase = poke%4
    var pai :String = ""
    if huase == 0 {
        pai = "diamond "+String(count)
    }
    if huase == 1{
        pai = "club "+String(count)
    }
    if huase == 2{
        pai = "heart "+String(count)
    }
    if huase == 3{
        pai = "spade "+String(count)
    }
    return pai
}



func catchpoke(pokes:[Int]) -> Void {
    var select = [String]();
    var poke1=pokes
    
    
    
    
    
    
}
